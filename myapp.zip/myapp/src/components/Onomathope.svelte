<script>

</script>


<!-- creative commons BY-NC http://www.pngall.com/kitten-png/download/7247 -->
<img
	class="curious"
	alt="Kitten wants to know what's going on"
	src="https://image.jimcdn.com/app/cms/image/transf/dimension=350x1024:format=png/path/s5c2e8305651a0d08/image/ib321bf741ed4e0ba/version/1512680022/image.png"
>

<style>
	img {
		position: absolute;
        left: 1154px;
    	top: 1950px;
		height: 180px;
		bottom: -60px;
		transform: translate(-80%, 0) rotate(-30deg);
		transform-origin: 100% 100%;
		transition: transform 0.4s;
		z-index: 9999;
	}

	.curious {
		transform: translate(-95%, 0) rotate(0deg);
		transform: scale(1);


	}

</style>
